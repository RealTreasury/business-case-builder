# AI Instructions for admin/

- Contains code for WordPress dashboard functionality.
- Class files should use the `RTBCB_Admin` prefix.
- Files ending in `-page.php` should render admin screens; escape all output.
- Use WordPress nonce functions for form submissions.
