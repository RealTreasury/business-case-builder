# AI Instructions for public/

- Front-end hooks and assets for the plugin belong here.
- Use the `RTBCB_Public` prefix for classes.
- Escape all output before rendering.
